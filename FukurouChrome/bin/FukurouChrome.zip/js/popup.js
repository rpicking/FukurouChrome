var streamResults = document.getElementById('stream-results')

function start() {
    var follows = "https://api.twitch.tv/VangardMk/streams/followed"
    fetch(follows)
        .then(
            function(response) {
                if (response.status !== 200) {
                    console.log('Looks like there was a problem. Status Code: ' +
                        response.status);
                    return;
                }
                response.json().then(function(data) {
                    console.log(data);
                    //var htmlContent = '';
                    //streamResults.innerHTML = htmlContent;
                });
            }
        )
        .catch(function(err) {
            console.log('Fetch Error :-S', err);
        });
}

start()