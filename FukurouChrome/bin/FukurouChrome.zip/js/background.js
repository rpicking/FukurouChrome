var online = [];
var streamResults = document.getElementById('stream-results')
var htmlContent = '';

function start() {
    var follows = "https://api.twitch.tv/kraken/users/VangardMk/follows/channels?limit=100"
    var games = "https://api.twitch.tv/kraken/games/top"
    fetch(follows)
        .then(
            function(response) {
                if (response.status !== 200) {
                    console.log('Looks like there was a problem. Status Code: ' +
                        response.status);
                    return;
                }
                response.json().then(function(streamer) {
                    console.log(streamer);
                    for (var i = 0; i < streamer.follows.length; ++i) {
                        var name = streamer.follows[i].channel.name;
                        var live = "https://api.twitch.tv/kraken/streams/" + name;

                        fetch(live)
                            .then(
                                function (response) {
                                    if (response.status !== 200) {
                                        console.log('Looks like there was a problem. Status Code: ' +
                                            response.status);
                                        return;
                                    }
                                    response.json().then(function (data) {
                                        console.log(data)
                                        stream = data.stream
                                        if (stream !== null) {     // channel is live
                                            //createStreamElement
                                            streamResults.innerHTML = htmlContent;

                                            
                                        }
                                    });
                                }
                            )
                            .catch(function(er) {
                                console.log('Fetch Error :-S', er);
                            });
                    }
                });
            }
        )
        .catch(function(err) {
            console.log('Fetch Error :-S', err);
        });
}


function createStreamElement(stream, htmlContent) {
    htmlContent += '<div class="stream"><span class="first-row">' + '<'
}
start()
//setInterval(start, 30000)